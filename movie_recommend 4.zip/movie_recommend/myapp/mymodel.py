import pandas as pd
from scipy.spatial.distance import cosine, euclidean



def distance(new, id_1, id_2):

    pt1 = new.loc[id_1, 'Romance':'News']
    pt2 = new.loc[id_2, 'Romance':'News']
    cos = cosine(pt1, pt2)
    
    euc = euclidean(new.loc[id_1, 'popularity':'rating'], new.loc[id_2, 'popularity':'rating'])
    dis = cos + euc
    
    return dis

def recommend(new, df, title, k=5):

    movie_title=df['original_title']
    movie_title.index=df['imdb_title_id']

    movie_id = movie_title[movie_title == title].index[0]
    predict = []
    for i in new.index[:500]:  # it will return the movie ids present for us in df
        if i == movie_id:
            continue
        dis = distance(new, i, movie_id)
        predict.append((dis, i))
    
    predict.sort()
    print(predict[:k])
    movies = []
    for dis, id_ in predict[:k]:
        movies.append(movie_title.loc[id_])
    return movies 