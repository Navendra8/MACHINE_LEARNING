from django.urls import path
from . import views 

urlpatterns = [
    path("", views.index),
    path("check_movie/", views.movie_page),
    path("aftermovie/", views.after_movie)
]