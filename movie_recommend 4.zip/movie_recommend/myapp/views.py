from django.shortcuts import render
from .mymodel import recommend
from django.http import HttpResponse
import pandas as pd
import requests
# Create your views here.
def index(request):
    return render(request, "index.html")

def movie_page(request):
    return render(request, "show.html")

def after_movie(request):
    if request.method == "GET":
        return render(request, "show.html")
    
    elif request.method == "POST":
        new = pd.read_csv("movies.csv")
        df = pd.read_csv('IMDb movies.csv')
        
        new.set_index("imdb_title_id", inplace=True)

        movie = request.POST.get("movie")
        movies = recommend(new, df, movie)
        all_movies = []
        for title in movies:
            key = "e22bdd41"
            url = f"http://www.omdbapi.com/?t={title}&apikey={key}"
            page = requests.get(url)
            if page.status_code == 200:
                data = page.json()
                year = data.get('Year')
                details = { 
                            "movie" : title,
                            "release" : data.get('Released'),
                            "run_time" : data.get('Runtime'),
                            "genre" : data.get('Genre'),
                            "actors" : data.get('Actors'),
                            "plot" : data.get("Plot"),
                            "lang" : data.get("Language"),
                            "poster" : data.get("Poster"),
                            "ratings" : data.get("imdbRating")
                }
                all_movies.append(details)
            else:
                all_movies.append({"title" : title})
        return render(request, "details.html", {"data" : all_movies})

    
